// script.js
let isContentChanged = false;

document.getElementById('changeContentBtn').addEventListener('click', function() {
    var content1 = document.getElementById('content1');
    var content2 = document.getElementById('content2');

    if (!isContentChanged) {
        // Atualiza para o novo conteúdo
        content1.innerHTML = `
            <img src="imagem2.jpg" alt="Nova Imagem 1" class="content-image">
            <p>Novo Texto da Div 2</p>
        `;
        content2.innerHTML = `
            <img src="imagem1.webp" alt="Nova Imagem 2" class="content-image">
            <p>Novo Texto da Div 1</p>
        `;
    } else {
        // Restaura o conteúdo original
        content1.innerHTML = `
            <img src="imagem1.webp" alt="Imagem 1" class="content-image">
            <p>Texto da Div 1</p>
        `;
        content2.innerHTML = `
            <img src="imagem2.jpg" alt="Imagem 2" class="content-image">
            <p>Texto da Div 2</p>
        `;
    }

    // Alterna o estado
    isContentChanged = !isContentChanged;
});

